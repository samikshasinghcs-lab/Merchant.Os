"""Tenant-owned operational security records for MerchantOS v1.3."""
from datetime import datetime, timezone
from sqlalchemy import String, Text, DateTime, ForeignKey, UniqueConstraint, JSON, Boolean, Index
from sqlalchemy.orm import Mapped, mapped_column
from .orm_base import Base

def utcnow(): return datetime.now(timezone.utc)

class MerchantPayPalCredential(Base):
    __tablename__='merchant_paypal_credentials'
    __table_args__=(UniqueConstraint('tenant_id','environment',name='uq_paypal_credential_tenant_env'),)
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    tenant_id: Mapped[str]=mapped_column(ForeignKey('tenants.id',ondelete='CASCADE'),nullable=False,index=True)
    environment: Mapped[str]=mapped_column(String(12),nullable=False)
    client_id: Mapped[str]=mapped_column(Text,nullable=False)
    encrypted_client_secret: Mapped[str]=mapped_column(Text,nullable=False)
    webhook_id: Mapped[str]=mapped_column(String(200),nullable=False)
    active: Mapped[bool]=mapped_column(Boolean,default=True,nullable=False)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,nullable=False)

class PayPalWebhookEvent(Base):
    __tablename__='paypal_webhook_events'
    __table_args__=(UniqueConstraint('tenant_id','event_id',name='uq_paypal_event_tenant_id'),Index('ix_paypal_events_status','tenant_id','status'))
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    tenant_id: Mapped[str]=mapped_column(ForeignKey('tenants.id',ondelete='CASCADE'),nullable=False,index=True)
    event_id: Mapped[str]=mapped_column(String(200),nullable=False)
    event_type: Mapped[str]=mapped_column(String(200),nullable=False)
    payload: Mapped[dict]=mapped_column(JSON,nullable=False)
    status: Mapped[str]=mapped_column(String(30),default='RECEIVED',nullable=False)
    received_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,nullable=False)
    processed_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    error: Mapped[str|None]=mapped_column(Text)

class PactPartyApproval(Base):
    __tablename__='pact_party_approvals'
    __table_args__=(UniqueConstraint('tenant_id','agreement_id','agreement_version','user_id',name='uq_pact_party_approval'),)
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    tenant_id: Mapped[str]=mapped_column(ForeignKey('tenants.id',ondelete='CASCADE'),nullable=False,index=True)
    agreement_id: Mapped[str]=mapped_column(String(100),nullable=False,index=True)
    agreement_version: Mapped[int]=mapped_column(nullable=False)
    user_id: Mapped[str]=mapped_column(ForeignKey('users.id',ondelete='CASCADE'),nullable=False)
    decision: Mapped[str]=mapped_column(String(20),nullable=False)
    statement_hash: Mapped[str]=mapped_column(String(64),nullable=False)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,nullable=False)

class MerchantInvitation(Base):
    __tablename__='merchant_invitations'
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    tenant_id: Mapped[str]=mapped_column(ForeignKey('tenants.id',ondelete='CASCADE'),nullable=False,index=True)
    email: Mapped[str]=mapped_column(String(320),nullable=False,index=True)
    role: Mapped[str]=mapped_column(String(20),nullable=False)
    token_hash: Mapped[str]=mapped_column(String(64),nullable=False,unique=True)
    expires_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),nullable=False)
    accepted_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=utcnow,nullable=False)
