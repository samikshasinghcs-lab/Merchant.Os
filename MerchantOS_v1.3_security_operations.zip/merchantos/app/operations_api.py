"""Authenticated tenant administration and trust-operation endpoints."""
import os
from fastapi import APIRouter, Depends, HTTPException, Request
from . import auth as identity
router=APIRouter(prefix='/api/v1/operations',tags=['tenant-operations'])
def principal(p=Depends(identity.current_principal)):
    if not identity.AUTH_AVAILABLE: raise HTTPException(503,'Identity dependencies unavailable')
    return p
@router.put('/paypal-credentials')
def paypal_credentials(body:dict,p=Depends(principal)):
    if p['role'] not in {'OWNER','ADMIN'}: raise HTTPException(403,'OWNER or ADMIN required')
    from .tenant_operations import save_paypal_credentials
    try: return save_paypal_credentials(p['tenant_id'],body.get('environment','sandbox'),body.get('client_id',''),body.get('client_secret',''),body.get('webhook_id',''))
    except Exception as e: raise HTTPException(400,str(e))
@router.post('/invitations')
def invite(body:dict,p=Depends(principal)):
    from .tenant_operations import create_invitation
    try: return create_invitation(p,body.get('email',''),body.get('role','OPERATOR'))
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
@router.post('/invitations/accept')
def accept(body:dict,p=Depends(principal)):
    from .tenant_operations import accept_invitation
    try: return accept_invitation(p['user_id'],body.get('token',''))
    except PermissionError as e: raise HTTPException(403,str(e))
    except Exception as e: raise HTTPException(400,str(e))
@router.post('/agreements/{agreement_id}/approvals')
def approve(agreement_id:str,body:dict,p=Depends(principal)):
    from .tenant_operations import record_pact_approval
    try: return record_pact_approval(p,agreement_id,int(body.get('version',0)),body.get('decision',''),body.get('statement',''))
    except Exception as e: raise HTTPException(400,str(e))
@router.post('/paypal/webhooks/{environment}')
async def webhook(environment:str,request:Request):
    event=await request.json()
    # Webhook tenant routing must be explicit and authenticated by configured webhook IDs.
    # Resolve tenant by trying active credential webhook IDs; do not trust event-supplied tenant IDs.
    from sqlalchemy import select
    from .auth_sqlalchemy import SessionLocal
    from .completion_models import MerchantPayPalCredential
    from .tenant_operations import receive_verified_webhook
    from .paypal_security import verify_webhook_signature
    headers=dict(request.headers)
    with SessionLocal() as s:
        rows=s.scalars(select(MerchantPayPalCredential).where(MerchantPayPalCredential.environment==environment,MerchantPayPalCredential.active.is_(True))).all()
        matches=[]
        for row in rows:
            from .paypal_security import decrypt_secret
            try:
                if verify_webhook_signature(headers,event,row.webhook_id,row.client_id,decrypt_secret(row.encrypted_client_secret),environment): matches.append(row.tenant_id)
            except Exception: continue
    if len(matches)!=1: raise HTTPException(401,'Webhook could not be uniquely authenticated')
    try: return receive_verified_webhook(matches[0],headers,event,environment)
    except Exception as e: raise HTTPException(401,str(e))
