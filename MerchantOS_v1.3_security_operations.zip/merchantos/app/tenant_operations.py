"""Tenant-bound credential, webhook inbox, membership and PACT approval services."""
import hashlib, hmac, json, os, uuid, secrets
from datetime import datetime, timedelta, timezone
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from .auth_sqlalchemy import SessionLocal, Membership, User
from .tenant_db import tenant_session
from .completion_models import MerchantPayPalCredential, PayPalWebhookEvent, PactPartyApproval, MerchantInvitation
from .paypal_security import encrypt_secret, decrypt_secret, verify_webhook_signature, CredentialError

ROLES={'ADMIN','OPERATOR','VIEWER'}
def _owner_admin(p):
    if p['role'] not in {'OWNER','ADMIN'}: raise PermissionError('OWNER or ADMIN role required')

def save_paypal_credentials(tenant_id, environment, client_id, client_secret, webhook_id):
    if environment not in {'sandbox','live'}: raise ValueError('environment must be sandbox or live')
    if not all([client_id.strip(),client_secret,webhook_id.strip()]): raise ValueError('PayPal client ID, secret and webhook ID are required')
    encrypted=encrypt_secret(client_secret)
    with tenant_session(tenant_id) as s:
        row=s.scalar(select(MerchantPayPalCredential).where(MerchantPayPalCredential.tenant_id==tenant_id,MerchantPayPalCredential.environment==environment))
        if row:
            row.client_id=client_id.strip(); row.encrypted_client_secret=encrypted; row.webhook_id=webhook_id.strip(); row.active=True; row.updated_at=datetime.now(timezone.utc)
        else:
            row=MerchantPayPalCredential(id=str(uuid.uuid4()),tenant_id=tenant_id,environment=environment,client_id=client_id.strip(),encrypted_client_secret=encrypted,webhook_id=webhook_id.strip(),active=True); s.add(row)
    return {'environment':environment,'configured':True}

def get_paypal_credentials(tenant_id, environment):
    with tenant_session(tenant_id) as s:
        row=s.scalar(select(MerchantPayPalCredential).where(MerchantPayPalCredential.tenant_id==tenant_id,MerchantPayPalCredential.environment==environment,MerchantPayPalCredential.active.is_(True)))
        if not row: return None
        return {'client_id':row.client_id,'client_secret':decrypt_secret(row.encrypted_client_secret),'webhook_id':row.webhook_id,'environment':row.environment}

def receive_verified_webhook(tenant_id, headers, event, environment):
    creds=get_paypal_credentials(tenant_id,environment)
    if not creds: raise PermissionError('PayPal credentials are not configured for this merchant')
    if not verify_webhook_signature(headers,event,creds['webhook_id'],creds['client_id'],creds['client_secret'],environment): raise PermissionError('PayPal webhook signature verification failed')
    event_id=str(event.get('id') or '').strip(); event_type=str(event.get('event_type') or '').strip()
    if not event_id or not event_type: raise ValueError('Webhook event id and event_type are required')
    with tenant_session(tenant_id) as s:
        existing=s.scalar(select(PayPalWebhookEvent).where(PayPalWebhookEvent.tenant_id==tenant_id,PayPalWebhookEvent.event_id==event_id))
        if existing: return {'accepted':True,'duplicate':True,'status':existing.status}
        s.add(PayPalWebhookEvent(id=str(uuid.uuid4()),tenant_id=tenant_id,event_id=event_id,event_type=event_type,payload=event,status='RECEIVED'))
    return {'accepted':True,'duplicate':False,'status':'RECEIVED'}

def create_invitation(principal,email,role='OPERATOR',hours=72):
    _owner_admin(principal); email=email.strip().lower()
    if role not in ROLES: raise ValueError('Invited role must be ADMIN, OPERATOR or VIEWER')
    raw=secrets.token_urlsafe(32); digest=hashlib.sha256(raw.encode()).hexdigest()
    with tenant_session(principal['tenant_id']) as s:
        s.add(MerchantInvitation(id=str(uuid.uuid4()),tenant_id=principal['tenant_id'],email=email,role=role,token_hash=digest,expires_at=datetime.now(timezone.utc)+timedelta(hours=hours)))
    return {'email':email,'role':role,'invitation_token':raw,'expires_in_hours':hours}

def accept_invitation(user_id, token):
    digest=hashlib.sha256(token.encode()).hexdigest()
    with SessionLocal() as s:
        invite=s.scalar(select(MerchantInvitation).where(MerchantInvitation.token_hash==digest))
        if not invite or invite.accepted_at or invite.expires_at < datetime.now(timezone.utc): raise ValueError('Invitation is invalid, expired or already used')
        user=s.get(User,user_id)
        if not user or user.email.lower()!=invite.email: raise PermissionError('Invitation email does not match authenticated account')
        s.add(Membership(user_id=user.id,tenant_id=invite.tenant_id,role=invite.role)); invite.accepted_at=datetime.now(timezone.utc); s.commit()
        return {'tenant_id':invite.tenant_id,'role':invite.role}

def record_pact_approval(principal, agreement_id, version, decision, statement):
    if decision not in {'APPROVE','REJECT'}: raise ValueError('decision must be APPROVE or REJECT')
    if not statement or len(statement.strip())<10: raise ValueError('A meaningful approval statement is required')
    digest=hashlib.sha256(statement.strip().encode()).hexdigest()
    with tenant_session(principal['tenant_id']) as s:
        existing=s.scalar(select(PactPartyApproval).where(PactPartyApproval.tenant_id==principal['tenant_id'],PactPartyApproval.agreement_id==agreement_id,PactPartyApproval.agreement_version==version,PactPartyApproval.user_id==principal['user_id']))
        if existing: raise ValueError('This user has already approved or rejected this agreement version')
        s.add(PactPartyApproval(id=str(uuid.uuid4()),tenant_id=principal['tenant_id'],agreement_id=agreement_id,agreement_version=version,user_id=principal['user_id'],decision=decision,statement_hash=digest))
    return {'agreement_id':agreement_id,'version':version,'decision':decision,'actor_user_id':principal['user_id'],'statement_sha256':digest,'recorded':True}
