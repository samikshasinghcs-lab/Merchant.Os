# Security and tenancy status — v1.0 foundation

## Implemented
- SQLAlchemy 2 identity models for users, tenants and memberships.
- Alembic initial migration for identity tables.
- Password hashing (Passlib bcrypt), signed JWT access tokens and expiry.
- API authentication middleware when `AUTH_REQUIRED=true`.
- Basic role gates: OWNER/ADMIN/OPERATOR can write; OWNER/ADMIN only for refund approval, payment capture, dispute evidence submission and payment routes.
- Workspace member listing and role-change endpoints scoped by the membership's tenant ID.
- Docker Compose PostgreSQL service, separate frontend container and API reverse proxy.

## Deliberate single-merchant pilot restriction
The existing business-domain modules (orders, reviews, refunds, evidence, disputes, agreements, milestones and audit) still use the legacy SQLite repository. Their rows and SQL queries do not yet carry a `tenant_id`. Therefore this release **does not claim multi-merchant data isolation**. The registration endpoint permits only one tenant/workspace and returns HTTP 409 if a second workspace is attempted. This is a fail-closed restriction, not multi-tenancy. Do not remove it until every business table, query, background task, file path, PayPal credential and audit event is tenant-scoped and covered by isolation tests.

## RBAC limitations
The middleware currently applies coarse role checks to HTTP methods and financial/dispute endpoints. It is not yet a full permission matrix, and role assignment/invitation workflows need stronger owner-only safeguards and audit logging. Buyer and freelancer party-name comparisons in PACT are not identity authentication.

## Storage limitation
PostgreSQL currently stores the identity/workspace directory. Legacy merchant-domain records remain in SQLite at `DATABASE_PATH` (mounted volume in Compose). This is a transitional dual-store deployment, not a completed PostgreSQL migration.

## Required before public production
1. Migrate all domain tables to SQLAlchemy/PostgreSQL with `tenant_id` foreign keys and tenant-scoped repository methods.
2. Add PostgreSQL row-level security or equivalent query enforcement; test cross-tenant read/write denial.
3. Add invitation flows, verified email, MFA for financial approvals, refresh-token rotation/revocation and password reset.
4. Replace coarse role checks with explicit permission dependencies per endpoint.
5. Store PayPal credentials per tenant in a managed secret store; encrypt at rest and never use shared global credentials.
6. Move evidence files to private object storage with tenant-prefixed authorization, malware scanning and signed access URLs.
7. Add CSRF protection if cookie auth is adopted, rate limits, security headers, structured logs, monitoring, backups and incident response.
8. Deploy behind HTTPS and complete a security review.

`AUTH_REQUIRED=true` is enabled in Docker Compose. Change `JWT_SECRET_KEY` to a cryptographically random secret before running it. The default secret is for local development only.
