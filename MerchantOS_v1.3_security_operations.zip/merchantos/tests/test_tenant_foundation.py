import pytest
from app import domain_models
from app.tenant_db import require_tenant

def test_all_domain_tables_have_tenant_id():
    names=['merchant_orders','merchant_reviews','merchant_refunds','merchant_disputes','merchant_evidence','merchant_audit_events']
    for name in names:
        table=domain_models.Base.metadata.tables[name]
        assert 'tenant_id' in table.c
        assert table.c.tenant_id.nullable is False

def test_unscoped_session_is_rejected():
    class FakeSession: info={}
    with pytest.raises(PermissionError): require_tenant(FakeSession())

def test_refund_idempotency_is_unique_per_tenant():
    constraints=[c for c in domain_models.TenantRefund.__table__.constraints if getattr(c,'name',None)=='uq_refund_tenant_idem']
    assert len(constraints)==1
    assert {col.name for col in constraints[0].columns}=={'tenant_id','idempotency_key'}
