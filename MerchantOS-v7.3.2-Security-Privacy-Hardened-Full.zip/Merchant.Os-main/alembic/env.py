from logging.config import fileConfig
import os
from alembic import context
from sqlalchemy import engine_from_config, pool
from app.auth_sqlalchemy import Base  # registers tenant and user identity tables
from app import domain_models  # noqa: F401
config=context.config
if config.config_file_name: fileConfig(config.config_file_name)
url=os.getenv('IDENTITY_DATABASE_URL') or os.getenv('DATABASE_URL') or 'sqlite:///./merchantos_identity.db'
if url.startswith('postgres://'): url=url.replace('postgres://','postgresql+psycopg://',1)
if url.startswith('postgresql://'): url=url.replace('postgresql://','postgresql+psycopg://',1)
config.set_main_option('sqlalchemy.url',url.replace('%','%%'))
target_metadata=Base.metadata
def run_migrations_offline():
 context.configure(url=url,target_metadata=target_metadata,literal_binds=True,dialect_opts={'paramstyle':'named'},compare_type=True)
 with context.begin_transaction(): context.run_migrations()
def run_migrations_online():
 connectable=engine_from_config(config.get_section(config.config_ini_section),prefix='sqlalchemy.',poolclass=pool.NullPool)
 with connectable.connect() as connection:
  context.configure(connection=connection,target_metadata=target_metadata,compare_type=True)
  with context.begin_transaction(): context.run_migrations()
if context.is_offline_mode(): run_migrations_offline()
else: run_migrations_online()
