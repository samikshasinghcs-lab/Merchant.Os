# MerchantOS AI repair + PayPal MCP bundle

## What this adds
- A manually triggered Codex workflow that can safely inspect an optional ZIP committed in the repository.
- Codex-generated changes are exported as a patch, applied in a separate job, checked with the repository's backend/frontend tests, and proposed as a PR. It never pushes directly to `main`.
- A PayPal official remote MCP developer connection configured for Sandbox, while retaining the existing `ag-mcp` entry.
- Explicit safeguards for demo data, secrets, tenant boundaries, and human approval of financial actions.

## Install from Android / GitHub web
1. Extract this ZIP on your device.
2. In the repository, create `.github/workflows/ai-repair.yml` and paste the matching file.
3. Create `.github/codex/prompts/merchantos-repair.md` and paste the matching prompt.
4. Replace the repository `.mcp.json` with the included version (it preserves `ag-mcp` and adds PayPal Sandbox).
5. Create `docs/PAYPAL_MCP_SANDBOX.md` and paste the included guide.
6. Add `INSTALL_AND_RUN.md` only if desired.
7. Commit the files.

## Required GitHub secret
In repository Settings → Secrets and variables → Actions, add:
- `OPENAI_API_KEY` — an OpenAI API key for the Codex GitHub Action.

Do not add PayPal credentials as GitHub Actions secrets for this repair workflow. PayPal MCP authentication is handled by the compatible developer MCP host using PayPal's consent flow or a locally injected sandbox token.

## Run the workflow
1. Open Actions → `MerchantOS AI Repair (Codex)` → Run workflow.
2. Choose `main`.
3. In `archive_path`, enter the exact path of the ZIP committed to the repository, for example `uploads/merchantos-full.zip`. Leave blank to audit the repository alone.
4. Run it. Review the generated PR carefully; do not auto-merge.

The ZIP must first exist in the GitHub repository. A ZIP that is only on your phone or only attached to this chat is not visible to GitHub Actions.

## Important
The workflow cannot run without `OPENAI_API_KEY`. The repair agent treats archive contents as untrusted data and never executes scripts from the ZIP. It does not migrate databases, touch live PayPal, or mutate demo records. The PayPal MCP config is a developer-client connection, not proof that Render's backend is already connected to MCP.
