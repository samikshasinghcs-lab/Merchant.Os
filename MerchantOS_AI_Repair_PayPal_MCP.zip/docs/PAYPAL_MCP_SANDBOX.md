# PayPal MCP — Sandbox configuration

MerchantOS already has a PayPal REST adapter (`app/paypal.py`). This adds a **developer MCP-client connection** to PayPal's official remote MCP server; it does not by itself install an MCP client inside the Render/FastAPI process.

## Configuration

The repository `.mcp.json` keeps the existing `ag-mcp` entry and adds PayPal's official sandbox endpoint:

`https://mcp.sandbox.paypal.com/http`

Use a compatible MCP host that supports remote Streamable HTTP MCP servers. Complete PayPal's authentication/consent flow in that host. Do not paste credentials into `.mcp.json`, source code, issues, or commits.

For a local PayPal MCP process instead of the remote endpoint, PayPal documents the official package:

```json
{
  "mcpServers": {
    "paypal": {
      "command": "npx",
      "args": ["-y", "@paypal/mcp", "--tools=all"],
      "env": {
        "PAYPAL_ACCESS_TOKEN": "${PAYPAL_ACCESS_TOKEN}",
        "PAYPAL_ENVIRONMENT": "SANDBOX"
      }
    }
  }
}
```

Only use a host that securely injects `PAYPAL_ACCESS_TOKEN` from its environment/secret store. Never put the actual token in the JSON file. The local package requires Node.js 18 or later.

## Safety boundary

- Sandbox only. Do not use `https://mcp.paypal.com`, `PRODUCTION`, or `LIVE`.
- MCP access does not grant permission to bypass MerchantOS authentication, tenant scoping, human approval, idempotency, reconciliation, or audit logging.
- Do not enable autonomous refunds, captures, payouts, or other money-moving actions.
- Keep the existing MerchantOS REST checkout/capture integration intact.
- The `.mcp.json` connection is for a compatible developer MCP host. A deployed server-side integration requires a separately implemented and secured MCP client, runtime secret management, authorization mapping, and tests; this configuration does not claim that deployment is complete.

## Official references

- PayPal MCP quickstart: https://developer.paypal.com/ai-tools/mcp-server
- Official PayPal MCP server: https://github.com/paypal/paypal-mcp-server
